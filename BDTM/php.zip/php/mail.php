<?php
//$file = fopen("titanic.csv", "r");
//echo fread($file,"100");
 
/*$filename = "titanic.csv";    
$fr = fopen($filename, "r");//open file in read mode    
  
$contents = fread($fr, filesize($filename));//read file    
  
echo "<pre>$contents</pre>";//printing data of file  
fclose($fr); //close file    
*/

$filename = fopen("titanic.csv", "r");
echo " <table border='1'>";
while(!feof($filename)){

    $line = fgets($filename); // open file in read mode
    $splited_line_arry = explode(",", $line);

    //echo $line;

     if (count($splited_line_arry)==12){

            echo " 
            
            
                 <tr>
                   <td>$splited_line_arry[0]</td>
                     <td>$splited_line_arry[1]</td>
                     <td>$splited_line_arry[2]</td>
                     <td>$splited_line_arry[3]</td>
                     <td>$splited_line_arry[4]</td>
                     <td>$splited_line_arry[5]</td>
                     <td>$splited_line_arry[6]</td>
                     <td>$splited_line_arry[7]</td>
                     <td>$splited_line_arry[8]</td>
                     <td>$splited_line_arry[9]</td>
                     <td>$splited_line_arry[10]</td>
                     <td>$splited_line_arry[11]</td>
                 </tr>
            
             ";
     }
  }
echo " </table>";
fclose($filename);
?>    


