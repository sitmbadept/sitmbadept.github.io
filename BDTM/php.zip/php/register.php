<?php
include 'connect.php';
if(isset($_POST['register'])){
    $id=$_POST['ID'];
    $name=$_POST['name'];
    $Email=$_POST['email'];
    $password=$_POST['password'];

    $sql="INSERT INTO register(ID, username, email, password) VALUES ('1','harshal','harshal@gmail.com','12345')";
    $conn->exec($sql);
    echo "data inserted successfully";
}
        

?>
