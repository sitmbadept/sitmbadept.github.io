<?php

//function db_connect(){
  try{    
      $server="localhost";
      $username="root";
      $password="";
      $dbname="registration";
      
        $conn=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
       echo "connection successfully";
  }
  catch(PDOException){
    echo "error" .$e->getmessage();
  }
  
/*return $conn;
}

function db_close($conn)
{*/
    $conn=null;
/*}

function data_select($conn, $tbl, $cols =" * ", $where=" 1 = 1"){
        
        $sql="SELECT $cols FROM $tbl WHERE $where";
        $resultSet=$conn->query($sql);
      return $resultSet->fetchAll(PDO::FETCH_ASSOC);
}



function common($conn, $qry){
    
    $result=$conn->query($qry);
    return $result;

  }*/