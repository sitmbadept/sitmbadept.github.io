<?php
    //try{
    include 'connect.php';
    if(isset($_POST['submit'])){
        $name=$_POST['name'];
        $Email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $password=$_POST['password'];


        $conn = db_connect();


        //$sql="INSERT INTO crud(name,email,mobile,password) VALUES ('$name','$Email','$mobile','$password')";
        $sql = " SELECT * FROM test";
        $re = common($conn, $sql);
        print_r($re->fetchAll(PDO::FETCH_ASSOC));


        $cols = " (name,email,mobile,password) ";
        $value = " ('$name','$Email','$mobile','$password') ";
        $table= " crud ";

        db_close($conn);
    }
    ?>




<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>crud opertaion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  </head>
  <body>
        <div  class="container my-5">
        <form  method="post">

        <div class="mb-3">
        <label>name:</label>
        <input type="text" class="form-control" 
        placeholder="Enter your name" name="name" autocomplete="off">
        </div>

        <div class="mb-3">
        <label>Email:</label>
        <input type="email" class="form-control" 
        placeholder="Enter your Email" name="email" autocomplete="off">
        </div>
    
        <div class="mb-3">
        <label>Mobile Number:</label>
        <input type="text" class="form-control" 
        placeholder="Enter your Mobile number" name="mobile" autocomplete="off">
        </div>

        <div class="mb-3">
        <label>password:</label>
        <input type="text" class="form-control" 
        placeholder="Enter your password" name="password" autocomplete="off">
        </div>

         <button type="submit" class="btn
          btn-primary" name="submit">Submit</button>
</form> 

    </div>
     </body>
</html>
