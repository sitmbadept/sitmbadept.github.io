<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <pre>
<form name='registration' action='' method='POST'>
<label>Enter user name: </label>
<input type="text" name="username" />

<label>Email address</label>
<input type="text" name="mobile number" />

<label> Contact: </label>
<input type="text" name="contact" />

<label for 'gender'>gender: </label>
<input type="text" name="gender" />

<label for 'City'>City: </label>
<input type="text" name="location" />
</pre>
<button type="submit">INSERT</button>
<button type="submit">UPDATE</button>
<button type="submit">DELETE</button>
</body>
</html>
<?php
/*try{
$server="localhost";
$username="root";
$password="";
$dbname="student";

  $conn=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
   //$sql= "SELECT * FROM student_info";
   $sql="INSERT INTO student_info(StudentName,Address,PostalCode,City) values('henna','bhuj','476987','mumbai')";
   $r=$conn->exec($sql);
   //$res=$r->fetchAll(PDO::FETCH_ASSOC);
   //print_r($res);
 echo "insert successfully";
}
catch(PDOException $e){
  echo "error" .$e->getmessage();
}*/



























