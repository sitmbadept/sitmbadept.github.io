
<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action='index.php' method="Post">
 
    
        <h3 align="center">  REGISTRAION FORM  </h3>
        <pre align="center">
          name: <input type="text" name="name" value="" autocomplete="off" require></br>
          Email: <input type="email" name="email" value="" autocomplete="off" require></br>
       Password: <input type="password" name="password" value="" autocomplete="off" require></br>
       <input type="submit" name="register" value="Register"> <input type="submit" name="cancel" value="Cancel">

        


         </pre>
    </form>

</body>
</html>