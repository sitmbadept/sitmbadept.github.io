<?php
include 'connect.php';
/*$server="localhost";
$username="root";
$password="";
$dbname="registration";

  $conn=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);*/
  /*if
  $sql="select * from login";
    $selectquery=$conn->query($sql);
  $e=$selectquery->fetchAll(PDO::FETCH_ASSOC);
  print_r($e);*/
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  </head>
  <body>
    <form action="index.php" method="post">
        <pre align="center">



        username:<input type="text" name="name" value=""></br>
           email:<input type="email" name="email" value=""></br>
        <button type="submit" name="login" value="login"> login </button>
        </pre>
    </form>
    
  </body>
  </html>