<?php

    if(isset($_GET['submit']) == 1)
    {
        $username = $_GET['name'];
        $password = $_GET['password'];
       

        header("location: ./home.php?username=$username");

         if(($username == 'admin') & ($password=='admin')){
            header("location: ./home.php?username=$username");
         }
        else{
            echo "Invalid Username!!!";
         }


    }