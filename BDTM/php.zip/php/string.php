<?php

$filename = fopen("monthly.csv", "r");
echo " <table border='1'>" ;
while(!feof($filename)){

    $line = fgets($filename); // open file in read mode
    $splited_line_arry = explode(",", $line);

    //echo $line;

     if (count($splited_line_arry)==5){

        $date_entry = $splited_line_arry[1];
        if ($date_entry != "Date"){
            $time = strtotime($splited_line_arry[1]);
            $final_date = date('d-F-Y',$time);
        }
        else{
            $final_date = $date_entry;
        }
            
        
        echo " 
                 <tr>
                   <td>$splited_line_arry[0]</td>
                     <td>$final_date</td>
                     <td>$splited_line_arry[2]</td>
                     <td>$splited_line_arry[3]</td>
                     <td>$splited_line_arry[4]</td>
                    </tr>    
             ";
     }
  }
echo " </table>";
fclose($filename);
?>    
