<?php

$file = fopen("monthly.csv", "r");
$category=array();
while(!feof($file)){
    
    $line = fgets($file);
    $data = explode(",", $line);
    if( count($data) != 1)
        array_push($category, $data[3]);
}
$category_unique = array_unique($category);
fclose($file);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form method="GET">
                                     
            Category : <select name='category' required>
                        <option value='-' disabled selected> </option>
                          
                         <?php
                                
                                foreach($category_unique as $c){
                                    if ($c!="Category")
                                        echo "<option value='".$c."'>$c</option>";
                                }
                                
                            ?>

                        </select>

            Date : <input type="date" name='date_entry' required/>

            <input type='submit'  name="submit-btn" />
    </form>



</table>

</body>
</html>

<?php

    if(isset($_GET['submit-btn'])){
        $date_entry= $_GET['date_entry'];
        $time = strtotime($date_entry);
        $date_entry = date('d-F-Y',$time);
    
        $category = $_GET['category'];

        echo "
        <Br/>
        <table border='1'>
        <tr>
            <th>Timestamp</th>
            <th>Date </th>
            <th>Item Name </th>
            <th>Category</th>
            <th>Amount </th>    
        </tr>";

        $file = fopen("monthly.csv", "r");
        while(!feof($file)){
    
            $line = fgets($file);
            $data = explode(",", $line);
       
            if( count($data) != 1)
            {
               
                if ($data[1] != "Date"){
                    $time = strtotime($data[1]);
                    $final_date = date('d-F-Y',$time);
                }
                if ($category == $data[3] && $date_entry == $final_date){
                    echo "
                    <tr>
                        <td>$data[0]</td>
                        <td>$final_date</td>
                        <td>$data[2]</td>
                        <td>$data[3]</td>
                        <td>$data[4]</td>    
                    </tr>"; 
            
                }
                   
            }

        }
        echo "</table>";
       fclose($file);
    }