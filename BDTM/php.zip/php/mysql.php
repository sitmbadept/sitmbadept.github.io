<?php
try{
 $host="localhost";
 $username="root";
 $password="";
 $dbname ="crudopertaion";

    $conn= new PDO ("mysql:host=$host;dbname=$dbname",$username,$password);
       // echo "connection successfully";
       // echo "</br>";

        // select database query
         /*$sql="Select * from crud";
          $result=$conn->query($sql);
          $r=$result->fetchAll(PDO::FETCH_ASSOC);
          print_r($r);*/

        // INSERT DATABASE
       // $sql= "INSERT INTO crud(name,email,mobile,password) VALUES ('henna','henna@gmail.com','32857443','7479')";
        //$r=$conn->exec($sql);
      
        $sql = "UPDATE crud SET name='henki' WHERE id=14";
         
        $r=$conn->prepare($sql);
       $result=$r->exec();

                echo 'updated successfully!';
       
        
}
catch(PDOException){
 // echo "error" .$e->getmessage();
}

  ?>
