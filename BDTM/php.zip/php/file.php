
<?php



//$string = 'The lazy fox jumped over the fence';
// echo str_contains($string, 'ths'); 
    
$file = fopen("monthly.csv", "r");
echo " <table border='1'> 

    <tr>
        <th>Timestamp</th>
        <th>Date </th>
        <th>Item Name </th>
        <th>Category</th>
        <th>Amount </th>    
    </tr>
    ";

$all_date_in_file = array();
    
while(!feof($file))
{

$line = fgets($file);
$splited_line_arry = explode (",", $line);

$no_of_columns_in_file = 5;
//echo $line;
$filter_date = "Y-F-s";




if(count($splited_line_arry) == $no_of_columns_in_file){

    $date = $splited_line_arry[1];
    $condition_flag = str_contains($date, $filter_date); 

 
   array_push($all_date_in_file, $date);
   
   



   if($condition_flag == 1)
    {
       
            

            echo "Filter Date based on Date : $filter_date";

            echo "
                <tr>
                <td>$splited_line_arry[0]</td>
                <td>$splited_line_arry[1]</td>
                <td>$splited_line_arry[2]</td>
                <td>$splited_line_arry[3]</td>
                <td>$splited_line_arry[4]</td>
                </tr> 
            ";
    }
}
}
echo "</table>";
fclose($file);


echo " Dates : <select name='date_dropdown'>";
foreach(array_unique($all_date_in_file) as $data){
    if ($data != "Date"){
    echo"
            <option value='$data'>$data</option>
        ";
    }
}

echo "<select>";
?>


Date <input type="date" />