<?php
  try{    
      $server="localhost";
      $username="root";
      $password="";
      $dbname="registration";
      
        $conn=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
       //echo "connection successfully";
  }
  catch(PDOException $e){
    echo "error" .$e->getmessage();
  }
  
    $conn=null;
?>