<?php
   // include 'connect.php';
    $server="localhost";
      $username="root";
      $password="";
      $dbname="registration";
      
        $conn=new PDO("mysql:host=$server;dbname=$dbname",$username,$password);
        if(isset($_POST['register'])){
            $name=$_POST['name'];
            $email=$_POST['email'];
            $password=$_POST['password'];
    
     
    $sql="INSERT INTO register(username, email, password) VALUES('$name','$email','$password')";
    $conn->exec($sql);
        }

$conn=null;



