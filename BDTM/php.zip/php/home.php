<?php
    $name = $_GET['username'];
    echo "<h1>Hello $name, <br> Welcome to PHP!!! </h1>";