scan(file="data.txt")


data = readLines("file1.txt")


con <- url("https://my.dnet.deloitte.com/in")
con
data <- readLines(con)
data




data =
  read.table("titanic.csv", sep=",", header=TRUE)


d =
  read.table("data2.txt", sep="|", header=TRUE)

d

write.table(d,"data3.txt", sep=";")

read.table("data3.txt", sep=";")


x = read.csv("data3.txt", sep=";", header=TRUE)


### Sink
sink("output.txt")
sample(1:100, 100, replace = T)
letters
LETTERS
data
sink()



install.packages("xlsx")
install.packages("readxl", dep=T)
library(readxl)

x <- read_excel("Superstore.xls", sheet = "People")
View(x)
?read_excel
?read_excel()

install.packages("rjson",dep=TRUE)
install.packages("rjson")
 from_json("./sample.json")

 
 
 
library(jsonify)
jsondata <- from_json("sample.json") 

df = data.frame(jsondata)

j_data = to_json(df)
j_data
writeLines(j_data, "sample1.json")




library(XML)

books <- xmlParse("books.xml")


rootnode <- xmlRoot(books)
rootSize <- xmlSize(rootnode)


View(rootnode[1])
rootnode[[1]][[3]]


cddetails <- xmlParse("catelog.xml")
cddetails
rootnode<- xmlRoot(cddetails)
rootnode[[1]][[1]]

df <- xmlToDataFrame(cddetails)
str(df)
saveXML(df,"s.xml")

content <- newXMLNode("Music")
saveXML(content)
saveXML(content, "newfile.xml")

View(df)
saveXML(df, "music.xml")



survey1 <- 
  
read_sav("https://github.com/sitmbadept/sitmbadept.github.io/blob/main/R/Unit-3/data/survey.sav")

View(survey1)

write_sav(survey,"new_surv")
d <- read_sas("airline.sas7bdat")
write_sas()
