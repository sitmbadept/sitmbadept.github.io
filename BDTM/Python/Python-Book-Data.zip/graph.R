
companies <- c("Tata", "Birla","Adani", "Mahindra")
turnover <- c(61,82,90,43)

colors <- c("red","green","pink","blue")
pie(turnover,
    turnover,
    col = colors, 
    main="Turnover in Million")
legend("bottomleft", companies,fill = colors)


month <- c("Jan","Feb", "Mar")
revenue <- c(17, 12, 30)
barplot(revenue,names.arg = month)

rev <- c(11,17,24,56,89,100,12,17,15,30)
hist(rev)


a <- c(7,12,28,23,38,41)
b <- c(15,17,15,18,23,33)
plot(a, type='l',col="red")
lines(b, type="l", col="blue")

col_list <- c("red","blue")
legend("top", c("a","b"), fill = col_list)
