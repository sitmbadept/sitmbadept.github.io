DROP DATABASE IF EXISTS emp_demo;
CREATE DATABASE IF NOT EXISTS emp_demo;
USE emp_demo;


DROP TABLE IF EXISTS employee;
CREATE TABLE employee (
ID text,
NAME text,
Age text,
City text,
state text,
country text
);


INSERT INTO employee VALUES ('1', 'John Todd', '35', 'Mumbai', NULL, NULL),
			    ('2', 'Paul S', 'Twenty Six', 'Tumkuru', NULL, NULL),
			    ('3', 'Dominic Dom', '40', 'Pune', NULL, NULL),
			    ('4', 'Rajat', '32', 'Bangalore', NULL, NULL),
			    ('5', 'Shruti', '28', 'Gandhinagar', NULL, NULL),
			    ('6', 'Tom', '30', 'Patna', NULL, NULL);